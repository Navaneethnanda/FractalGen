from FractalGen.Ifs import Shape,Ifs
